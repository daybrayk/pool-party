Project Name: Pool Party (Temp Title)

Unity Version: 2020.3.28

High Level Description: A top down 2D party shooter based around a backyard watergun fight. No matchmaking, just playing with friends.

Controls:

Move - WASD
Aim - Mouse
Shoot - Left Click
Recharge Weapon - R
Reload Weapon - R while near a water source
Shield - Left Shift
Switch Weapon -  Scroll wheel up/down

How to play/test:

Open two versions of the game, either using two builds or one running from the unity editor. Have one of the versions click the "Host" button in the top left corner, and then have the other click the "Client" button.
You should now both be in the same world and able to run around and shoot each other.

Known Issues:
Currently there are a few things that do not function properly from having to rework code to function in a multiplayer environment, some of these things include:
- Reloading/Recharging
- Ammo visuals on the HUD

When a player dies there is no respawning so you will have to exit the game and rejoin or create a new Hosted session

The line renderer for the automatic watergun does not work properly on Clients so "Water stream" will just look like a bunch of blue dots